<?php

namespace App\DataFixtures;

use App\Controller\WishController;
use App\Entity\Wish;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use function Symfony\Component\Clock\now;

class WishFixtures extends Fixture
{
    public function load(ObjectManager $manager): void
    {
        $wish = new Wish();
        $wish->setTitle("Title My_Title")
            ->setDescription("Description")
            ->setAuthor("author")
            ->setIsPublished(true)
            ->setDateCreated(new \DateTimeImmutable("now"));
        $manager->persist($wish);

        $wish = new Wish();
        $wish->setTitle("Title My_Title")
            ->setDescription("Description")
            ->setAuthor("author")
            ->setIsPublished(true)
            ->setDateCreated(new \DateTimeImmutable("now"));
        $manager->persist($wish);

        $manager->flush();
    }

}